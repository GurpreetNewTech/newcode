import React from "react"
import * as Icon from "react-feather"
const navigationConfig = [
  {
    id: "analytics",
    title: "Dashboard",
    type: "item",
    icon: <Icon.Home size={20} />,
    permissions: ["admin", "editor"],
    navLink: "/analytics"
  },
  // {
  //   id: "page2",
  //   title: "Student Reg",
  //   type: "item",
  //   icon: <Icon.File size={20} />,
  //   permissions: ["admin", "editor"],
  //   navLink: "/page2"
  // },
  {
    id: "admission",
    title: "Admission Details",
    type: "collapse",
    icon: <Icon.Server size={20} />,
    children: [
      {
        id: "studentReg",
        title: "Student Registration",
        type: "item",
        icon: <Icon.Circle size={12} />,
        permissions: ["admin", "editor"],
        navLink: "/student/reg"
      },
     
      {
        id: "studentlist",
        title: "Student List",
        type: "item",
        icon: <Icon.Circle size={12} />,
        permissions: ["admin", "editor"],
        navLink: "/student/listview"
      },
     
     
    
    ]
  }
]

export default navigationConfig
