import React from "react"
import Wizard from "./WizardComponent"
import { AvInput, AvGroup, AvFeedback, AvField } from "availity-reactstrap-validation"
import {
  Input,
  Label,
  Row,
  Col,
  Card,
  CardBody,
  CardTitle,
  CardHeader
} from "reactstrap"
import Checkbox from "../checkbox/CheckboxesVuexy"
import Radio from  "../radio/RadioVuexy"
import { Check } from "react-feather"
import Flatpickr from "react-flatpickr";
import Datepickers from '../../../views/forms/form-elements/datepicker/Datepickers';
import "flatpickr/dist/themes/light.css";
import "../../../assets/scss/plugins/forms/flatpickr/flatpickr.scss";

import NumberInputBasic from '../../../views/forms/form-elements/number-input/NumberInputBasic';

class WizardStudentRegistration extends React.Component {
  state = {
    testdob:  "",
    steps: [
      {
     
        title: 1,
        content: <Row>
          <Col md="6" sm="12">
            <AvGroup>
              <Label> Student Name, </Label>
              <AvInput name="student-name" type="text"  />
              <AvFeedback>Please enter valid Student Name</AvFeedback>
            </AvGroup>
          </Col>
          <Col md="6" sm="12">
            <AvGroup>
              {/* <Label> Last Name </Label> */}
              <Radio 
              
              color="primary"
              // icon={<Check className="vx-icon" size={16} />}
              label="male"
              defaultChecked={true}
              name="gender"   />
              <Radio  color="primary"
              // icon={<Check className="vx-icon" size={16} />}
              label="female"
              defaultChecked={false}
              name="gender"  />
            </AvGroup>
          </Col>
          <Col md="6" sm="12">
            <AvGroup>
              <Label> Email </Label>
              <AvInput name="last-name" type="email"  />
              <AvFeedback>Please enter valid email</AvFeedback>
            </AvGroup>
          </Col>
          <Col md="6" sm="12">

            <AvGroup>
              <AvField type="select" name="category-name" label="Category Type" >
                <option defaultValue>Select Category</option>
                <option>New York</option>
                <option>Chicago</option>
                <option>San Francisco</option>
                <option>Boston</option>
              </AvField>
            </AvGroup>
          </Col>
          <Col md="6" sm="12">
          <Label> DOB </Label>
          <Datepickers/>
          </Col>

          <Col md="6" sm="12">
          <Label> Adhar Number </Label>

          {/* <div > */}
          <NumberInputBasic   min={0} max={19}/>
            {/* <NumericInput className="form-control" min={0} max={100} value={10} noStyle /> */}
          {/* </div> */}

        
          </Col>
        
        
          
    
      
        </Row>
      },
      {
        title: 2,
        content: <Row>

<Col md="6" sm="12">
          <Label>   Student Contact No.</Label>

     
          <NumberInputBasic   min={0} max={10}/>
      

        
          </Col>

      
          <Col md="6" sm="12">
            <AvGroup>
              <Label> Father Name </Label>
              <AvInput name="father-name" type="text"   />
              <AvFeedback>Please enter valid Father Name</AvFeedback>
            </AvGroup>
          </Col> 
          <Col md="6" sm="12">
          <Label>   Father Contact No.</Label>

     
          <NumberInputBasic   min={0} max={10}/>
      

        
          </Col>

          <Col md="6" sm="12">
            <AvGroup>
              <Label> Father  Education </Label>
              {/* <Label className="mr-2">Requirements :</Label> */}
              <div className="stacked-checkbox">
                <div className="d-inline-block mr-2">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="10"
                    defaultChecked={true}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="12"
                    defaultChecked={false}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="UG"
                    defaultChecked={false}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="PG"
                    defaultChecked={false}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="other"
                    defaultChecked={false}
                  />
                </div>
              </div>
            </AvGroup>
          </Col>

          <Col md="6" sm="12">
            <AvGroup>
              <Label> Father  Occupation </Label>
              {/* <Label classNme="mr-2">Requirements :</Label> */}
              <div className="stacked-checkbox">
                <div className="d-inline-block mr-2">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="Service"
                    defaultChecked={true}
                  />
                </div>
                {/* <div className="d-inline-block mr-2">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="PvtService"
                    defaultChecked={false}
                  />
                </div> */}
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="Buisness"
                    defaultChecked={false}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="Farmer"
                    defaultChecked={false}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="Other"
                    defaultChecked={false}
                  />
                </div>
             
              </div>
            </AvGroup>
          </Col>
        </Row>
      },
      {
        title: 3,
        content: <Row>
          <Col md="6" sm="12">
            <AvGroup>
              <Label> Mother Name </Label>
              <AvInput name="motherName" type="text"  />
              {/* <AvFeedback>Event Name</AvFeedback> */}
            </AvGroup>
          </Col>
          <Col md="6" sm="12">
          <Label>   Mother Contact No.</Label>

     
          <NumberInputBasic   min={0} max={10}/>
      

        
          </Col>
          <Col md="6" sm="12">
            <AvGroup>
              <Label> Mother  Education </Label>
              {/* <Label className="mr-2">Requirements :</Label> */}
              <div className="stacked-checkbox">
                <div className="d-inline-block mr-2">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="10"
                    defaultChecked={true}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="12"
                    defaultChecked={false}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="UG"
                    defaultChecked={false}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="PG"
                    defaultChecked={false}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="other"
                    defaultChecked={false}
                  />
                </div>
              </div>
            </AvGroup>
          </Col>
          <Col md="6" sm="12">
            <AvGroup>
              <Label> Mother  Occupation </Label>
              {/* <Label className="mr-2">Requirements :</Label> */}
              <div className="stacked-checkbox">
                <div className="d-inline-block mr-2">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="Service"
                    defaultChecked={true}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="HouseWife"
                    defaultChecked={false}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="Buisness"
                    defaultChecked={false}
                  />
                </div>
                <div className="d-inline-block">
                  <Checkbox
                    color="primary"
                    icon={<Check className="vx-icon" size={16} />}
                    label="Other"
                    defaultChecked={false}
                  />
                </div>
               
              </div>
            </AvGroup>
          </Col>

    
     
          <Col md="6" sm="12">
            <AvGroup>
              <Label> Local and permanent address. </Label>
         
              <Input
            type="textarea"
            name="text"
            id="address"
            rows="3"
            placeholder="Address"
          />
            </AvGroup>
          </Col>
        </Row>
      }
    ]
  }

    
  render() {
    const { steps } = this.state
    return (
      <Card>
        <CardHeader>
          <CardTitle>Student Registratiion </CardTitle>
        </CardHeader>
        <CardBody>
          <Wizard
            validate
            steps={steps}
          />
        </CardBody>
      </Card>
    )
  }
}


export default WizardStudentRegistration
