import React, { Component } from 'react';
import { history } from "../../../history"
import {

  Col,
  Button
} from "reactstrap"
import { Edit, Trash } from "react-feather"
import { Link } from "react-router-dom"
export default class ChildMessageRenderer extends Component {
  constructor(props) {
    super(props);

    this.invokeEditMethod = this.invokeEditMethod.bind(this);
    this.invokeDelete = this.invokeDelete.bind(this);
  }

  invokeEditMethod() {
    history.push("/student/edit/"+this.props.data.id)

  
  }
  invokeDelete() {
  
    history.push("/student/listview")

  
  }


  render() {
    const  {id} =this.props.data;
    return (
     
<div>
<Link onClick={this.invokeEditMethod} >
<Edit size={15} />
<span className="align-middle ml-50">Edit</span>


</Link>
<span className="align-middle ml-50"></span>
<Link onClick={this.invokeDelete} style={{  padding: "2px",color:"red" }} >
<Edit size={15} />
<span className="align-middle ml-50">Delete</span>


</Link>

</div>
      


    
    );
  }
}