import React from "react"
import { Row, Col, Card, CardBody, CardHeader, CardTitle } from "reactstrap"
import Flatpickr from "react-flatpickr";

class Datepickers extends React.Component{
  state = {
   
    humanFriendly:  new Date(),
  
  }

  render(){

    let { 
      
          humanFriendly, 
   
        } = this.state

    return (
   
   
        // <Row>

        //   <Col  md="6" sm="12">
       
            <Flatpickr
              className="form-control"
              value={humanFriendly}
              options={{ altInput: true, altFormat: "F j, Y", dateFormat: "Y-m-d", }}
              onChange={date => {
                this.setState({ humanFriendly : date });
              }}
            />
        //   </Col>
       
        // </Row>
    
   )
  }
}

export default Datepickers