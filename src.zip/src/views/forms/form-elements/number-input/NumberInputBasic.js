import React from "react"
import NumericInput from "react-numeric-input"
import { Card, CardHeader, CardTitle, CardBody } from "reactstrap"
import { mobileStyle } from "./InputStyles"

function NumberInputBasic (props) {
  // render() {
    return (
      // <Card>
      //   <CardHeader>
      //     <CardTitle>Basic</CardTitle>
      //   </CardHeader>
      //   <CardBody>
          <NumericInput 
          required
          className={"form-control"}
          required={props.required}
            min={props.min}
            max={props.min}
         
            mobile
          noStyle
          />
      //   </CardBody>
      // </Card>
    )
  }
// }
export default NumberInputBasic
