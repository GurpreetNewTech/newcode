import React from "react"

class Page2 extends React.Component{
  render(){
    return <h4>This is Page 2.</h4>
  }
}

export default Page2