import React from "react"

class Home extends React.Component{
  render(){
    return <h4>You're Home.</h4>
  }
}

export default Home