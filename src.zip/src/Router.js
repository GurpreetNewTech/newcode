import React, { Suspense, lazy } from "react"
import { Router, Switch, Route } from "react-router-dom"
import { history } from "./history"
import { connect } from "react-redux"
import Spinner from "./components/@vuexy/spinner/Loading-spinner"
import { ContextLayout } from "./utility/context/Layout"


const Aggrid = lazy(() => import("./views/tables/aggrid/Aggrid"))
const analyticsCards = lazy(() =>
  import("./views/ui-elements/cards/analytics/Analytics")
)
// Route-based code splitting
const Home = lazy(() =>
  import("./views/pages/Home")
)

const Page2 = lazy(() =>
  import("./views/pages/Page2")
)

const login = lazy(() =>
  import("./views/pages/authentication/login/Login")
)

const StudentRegistrationForm = lazy(() =>
  import("./components/@vuexy/wizard/WizardStudentRegistration")
)
const vuexyWizard = lazy(() => import("./components/@vuexy/wizard/WizardStudentRegistration"))
// Set Layout and Component Using App Route
const RouteConfig = ({
  component: Component,
  fullLayout,
  permission,
  user,
  ...rest
}) => (
  <Route
    {...rest}
    render={props => {
      return (
        <ContextLayout.Consumer>
          {context => {
            let LayoutTag =
              fullLayout === true
                ? context.fullLayout
                : context.state.activeLayout === "horizontal"
                ? context.horizontalLayout
                : context.VerticalLayout
              return (
                <LayoutTag {...props} permission={props.user}>
                  <Suspense fallback={<Spinner />}>
                    <Component {...props} />
                  </Suspense>
                </LayoutTag>
              )
          }}
        </ContextLayout.Consumer>
      )
    }}
  />
)
const mapStateToProps = state => {
  return {
    user: state.auth.login.userRole
  }
}

const AppRoute = connect(mapStateToProps)(RouteConfig)

class AppRouter extends React.Component {
  render() {
    return (
      // Set the directory path if you are deploying in sub-folder
      <Router history={history}>
        <Switch>
          <AppRoute
            exact
            path="/"
            component={login}
            fullLayout
          />
          {/* <AppRoute
            path="/analyticsCards"
            component={analyticsCards}
          /> */}
          {/* <AppRoute
            path="/pages/login"
            component={login}
            fullLayout
          /> */}
    <AppRoute
            path="/analytics"
            component={analyticsCards}
            
          />
 <AppRoute path="/student/listview" component={Aggrid} /> 
  {/* <AppRoute
            path="/studentregistration"
            component={StudentRegistrationForm}
            fullLayout
          /> */}
   <AppRoute path="/student/reg" component={vuexyWizard} />
   <AppRoute path="/student/edit" component={vuexyWizard} />
        </Switch>
      </Router>
    )
  }
}

export default AppRouter
